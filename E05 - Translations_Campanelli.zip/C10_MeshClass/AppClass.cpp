#include "AppClass.h"

float value = 0.0;
void Application::InitVariables(void)
{
	m_pCameraMngr->SetPositionTargetAndUpward(
		vector3(0.0f, 0.0f, 10.0f),
		vector3(0.0f, 0.0f, 0.0f),
		vector3(0.0f, 1.0f, 0.0f)
	);

	//m_pCameraMngr->SetCameraMode(CAM_ORTHO_X);
	m_pMesh = new MyMesh();
	m_pMesh->GenerateCube(1.0f, C_BLACK);
}

void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();

}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();

	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix();
	matrix4 m4View = m_pCameraMngr->GetViewMatrix();

	/*	vector4 v4C1 = m4Model[0];
	vector4 v4C2 = m4Model[1];
	vector4 v4C3 = m4Model[2];
	vector4 v4C4 = m4Model[3];

// | 1    0    0    0 |
// | 0    1    0    0 |
// | 0    0    1    0 |
// | 0    0    0    1 |
// V4C1 V4C2 V4C3 V4C4

	//v4C4 = vector4(2.0f, 1.0f, -1.0f, 1.0f);
	v4C1[0] = 4.0f;
	v4C2[1] = 4.0f;
	v4C3[2] = 4.0f;
	v4C4 = vector4(2.0f, 1.0f, -1.0f, 1.0f);

	m4Model[0] = v4C1;
	m4Model[1] = v4C2;
	m4Model[2] = v4C3;
	m4Model[3] = v4C4;*/

	std::vector<matrix4> cubeVector;
	value += .01f;

	// row 1
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, 4.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, 4.0f, -2.0f)));
	// row 2
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-2.0f + value, 3.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(2.0f + value, 3.0f, -2.0f)));
	// row 3
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-2.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-1.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(0.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(1.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(2.0f + value, 2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, 2.0f, -2.0f)));
	// row 4
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-4.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-1.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(0.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(1.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, 1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(4.0f + value, 1.0f, -2.0f)));
	// row 5
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-5.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-4.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-2.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-1.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(0.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(1.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(2.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(4.0f + value, 0.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(5.0f + value, 0.0f, -2.0f)));
	// row 6
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-5.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-2.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-1.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(0.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(1.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(2.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, -1.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(5.0f + value, -1.0f, -2.0f)));
	// row 7
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-5.0f + value, -2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-3.0f + value, -2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(3.0f + value, -2.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(5.0f + value, -2.0f, -2.0f)));
	// row 8
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-2.0f + value, -3.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(-1.0f + value, -3.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(1.0f + value, -3.0f, -2.0f)));
	cubeVector.push_back(glm::translate(IDENTITY_M4, vector3(2.0f + value, -3.0f, -2.0f)));

	for (int i = 0; i < cubeVector.size(); i++)
	{
		m_pMesh->Render(m4Projection, m4View, cubeVector[i]);
	}

	//	NOT the same as m4Model = m4Model2 * m4Model
	//m4Model = m4Model * glm::scale(IDENTITY_M4, vector3(2.0f, 2.0f, 2.0f));

	//m4Model = ToMatrix4(m_qArcBall) * m4Model;
	
	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();

	//m_pMeshMngr->AddGridToRenderList();
	
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();

	//draw gui
	DrawGUI();
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	if (m_pMesh != nullptr)
	{
		delete m_pMesh;
		m_pMesh = nullptr;
	}
	SafeDelete(m_pMesh1);
	//release GUI
	ShutdownGUI();
}